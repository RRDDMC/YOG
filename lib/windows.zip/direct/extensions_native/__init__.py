"""
This package contains various Python methods that extend some of Panda's
underlying C++ classes.
"""
