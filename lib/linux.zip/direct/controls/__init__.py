"""
This package contains various types of character controllers, handling basic
control mechanics and setting up collisions for them.
"""
