"""
This package contains assorted utility classes.
"""
