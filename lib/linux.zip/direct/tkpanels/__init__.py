"""This package provides various GUI panels useful during Panda3D development
written using the Tkinter framework.
"""
